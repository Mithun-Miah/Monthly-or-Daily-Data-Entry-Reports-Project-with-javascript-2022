let days = document.getElementById("work_days");
let date = document.getElementById("work_date");
let amount = document.getElementById("work_amount");
let remarks = document.getElementById("remarks");
let total = document.getElementById("total");
let add_btn = document.getElementById("add_btn");

add_btn.addEventListener('click', function(e){
	e.preventDefault();
	
	if(days.value == '' || date.value == '' || amount.value == ''){
		alert("All Field Are Require!");
	}else{
		let tbody = document.getElementById("tbody");
		let tr = document.createElement('tr');
		
		let td = document.createElement('td');
		td.innerHTML = days.value;
		tr.appendChild(td);
		
		let td2 = document.createElement('td');
		td2.innerHTML = date.value;
		tr.appendChild(td2);
		
		let td3 = document.createElement('td');
		td3.innerHTML = amount.value;
		tr.appendChild(td3);
		
		let td4 = document.createElement('td');
		td4.innerHTML = remarks.value;
		tr.appendChild(td4);
		
		tbody.appendChild(tr);

		//total.innerHTML = td3.innerHTML;
	}
	
})